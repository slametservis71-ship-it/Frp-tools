# device_detector.py
import subprocess
import win32com.client # Hanya untuk Windows

class DeviceDetector:
    """Kelas untuk mendeteksi status perangkat yang terhubung."""

    def detect_adb(self):
        try:
            result = subprocess.check_output(["adb", "devices"], timeout=2).decode()
            return "device" in result.splitlines()[1] if len(result.splitlines()) > 1 else False
        except:
            return False

    def detect_fastboot(self):
        try:
            result = subprocess.check_output(["fastboot", "devices"], timeout=2).decode()
            return bool(result.strip())
        except:
            return False

    def detect_mtp(self):
        try:
            wmi = win32com.client.GetObject("winmgmts:")
            for usb in wmi.InstancesOf("Win32_PnPEntity"):
                if usb.Name and "MTP" in usb.Name:
                    return True
            return False
        except:
            return False

    def detect_download_mode(self):
        try:
            wmi = win32com.client.GetObject("winmgmts:")
            for usb in wmi.InstancesOf("Win32_PnPEntity"):
                id = usb.PNPDeviceID
                # Cek VID Samsung dan beberapa deskripsi umum untuk Download Mode
                if id and "VID_04E8" in id.upper(): # VID Samsung
                    if "MODEM" in str(usb.Name).upper() or \
                       "DOWNLOAD" in str(usb.Name).upper() or \
                       "SAMSUNG USB Mobile" in str(usb.Name).upper():
                        return True
            return False
        except Exception as e:
            return False

    def get_device_info(self):
        """Mengumpulkan dan mengembalikan informasi perangkat yang terdeteksi."""
        if self.detect_adb():
            try:
                model = subprocess.check_output(["adb", "shell", "getprop", "ro.product.model"], timeout=2).decode().strip()
                android = subprocess.check_output(["adb", "shell", "getprop", "ro.build.version.release"], timeout=2).decode().strip()
                
                frp_status = "Tidak diketahui"
                try:
                    # Mencoba beberapa properti FRP yang umum
                    frp_prop = subprocess.check_output(["adb", "shell", "getprop", "ro.frp.pst"], timeout=2).decode().strip()
                    if frp_prop:
                        frp_status = "Kemungkinan ON" if frp_prop == "1" else "Kemungkinan OFF"
                except:
                    pass # Abaikan jika properti tidak ditemukan

                return {
                    "status": "Perangkat terdeteksi via ADB",
                    "details": f"Model: {model}\nAndroid: {android}\nFRP: {frp_status}",
                    "mode": "adb"
                }
            except Exception as e:
                return {
                    "status": "Perangkat ADB terdeteksi, gagal ambil info",
                    "details": f"Error: {e}",
                    "mode": "adb"
                }
        elif self.detect_fastboot():
            return {
                "status": "Perangkat dalam mode Fastboot",
                "details": "Model: -\nAndroid: -\nFRP: -",
                "mode": "fastboot"
            }
        elif self.detect_download_mode():
            return {
                "status": "Perangkat dalam Download Mode (Samsung)",
                "details": "Model: -\nAndroid: -\nFRP: -",
                "mode": "download"
            }
        elif self.detect_mtp():
            return {
                "status": "Perangkat dalam mode MTP",
                "details": "Model: -\nAndroid: -\nFRP: -",
                "mode": "mtp"
            }
        else:
            return {
                "status": "Tidak ada perangkat terhubung",
                "details": "Model: -\nAndroid: -\nFRP: -",
                "mode": "none"
            }
