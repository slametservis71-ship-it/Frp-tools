# main.py
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, QFileDialog, QLabel, QGroupBox, QProgressBar
from PyQt5.QtGui import QFont
from PyQt5.QtCore import QTimer
import sys, os
import importlib.util # Untuk memuat modul secara dinamis

# --- Penting: Impor modul dari folder utama ---
# Pastikan plugin_interface.py dan device_detector.py berada di folder yang sama dengan main.py
from plugin_interface import FRPToolPlugin # Untuk mengenali kelas plugin
from device_detector import DeviceDetector  # Untuk deteksi perangkat

class FRPBypassTool(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("FRP Bypass Tool - Teknisi HP")
        self.setGeometry(100, 100, 900, 600)

        # Inisialisasi DeviceDetector
        self.device_detector = DeviceDetector()

        layout = QVBoxLayout()
        self.setLayout(layout)

        # Judul
        header = QLabel("📱 FRP BYPASS TOOL")
        header.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(header)

        # Info perangkat
        info_box = QGroupBox("🔍 Status Perangkat")
        info_layout = QVBoxLayout()
        self.device_info = QLabel("Tidak ada perangkat terhubung")
        self.device_details = QLabel("Model: -\nAndroid: -\nFRP: -")
        info_layout.addWidget(self.device_info)
        info_layout.addWidget(self.device_details)
        info_box.setLayout(info_layout)
        layout.addWidget(info_box)

        # Tombol aksi (akan diisi oleh plugin)
        # Pastikan self.button_box dan self.button_layout didefinisikan sebelum load_plugins()
        self.button_box = QGroupBox("🛠️ Menu Utama")
        self.button_layout = QHBoxLayout() # Simpan ini sebagai atribut kelas
        self.button_box.setLayout(self.button_layout)
        layout.addWidget(self.button_box)

        # Progress + Log
        self.progress = QProgressBar()
        self.progress.setTextVisible(True) # Tampilkan teks persentase
        self.progress.setValue(0) # Inisialisasi 0
        layout.addWidget(self.progress)

        log_box = QGroupBox("📝 Log Proses")
        log_layout = QVBoxLayout()
        self.log_console = QTextEdit()
        self.log_console.setReadOnly(True)
        log_layout.addWidget(self.log_console)
        log_box.setLayout(log_layout)
        layout.addWidget(log_box)

        # Panggil fungsi untuk memuat semua plugin
        self.load_plugins()

        # Deteksi otomatis perangkat
        self.timer = QTimer()
        self.timer.timeout.connect(self.auto_detect_device)
        self.timer.start(2000) # Cek setiap 2 detik

        self.log_console.append("Aplikasi siap. Menunggu deteksi perangkat...")

    def auto_detect_device(self):
        """Memperbarui informasi perangkat secara otomatis."""
        device_status = self.device_detector.get_device_info()
        self.device_info.setText(device_status["status"])
        self.device_details.setText(device_status["details"])

    def load_plugins(self):
        """Memuat semua plugin dari folder 'plugins/'."""
        # Dapatkan path absolut ke direktori 'plugins'
        # os.path.abspath(__file__) mendapatkan path lengkap file main.py
        # os.path.dirname(...) mendapatkan direktori tempat main.py berada
        plugin_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins")
        if not os.path.exists(plugin_dir):
            os.makedirs(plugin_dir)
            self.log_console.append(f"Direktori plugin '{plugin_dir}' dibuat.")

        self.log_console.append(f"Mencari plugin di: {plugin_dir}")
        loaded_count = 0
        for filename in os.listdir(plugin_dir):
            # Pastikan hanya file .py yang bukan __init__.py yang dimuat
            if filename.endswith(".py") and filename != "__init__.py":
                module_name = filename[:-3] # Hapus ekstensi .py untuk mendapatkan nama modul
                file_path = os.path.join(plugin_dir, filename)

                try:
                    # Memuat modul secara dinamis dari file
                    spec = importlib.util.spec_from_file_location(module_name, file_path)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)

                    # Iterasi semua item di dalam modul yang baru dimuat
                    for item_name in dir(module):
                        item = getattr(module, item_name)
                        # Cek apakah item adalah sebuah kelas, merupakan turunan dari FRPToolPlugin,
                        # dan bukan kelas FRPToolPlugin itu sendiri (agar tidak membuat instansnya sendiri)
                        if isinstance(item, type) and issubclass(item, FRPToolPlugin) and item is not FRPToolPlugin:
                            plugin_instance = item() # Buat instans dari kelas plugin
                            button = plugin_instance.create_button(self) # Panggil metode plugin untuk membuat tombol
                            # Hubungkan sinyal clicked tombol ke metode execute plugin
                            # Menggunakan lambda untuk meneruskan instans plugin dan callback log/progress
                            button.clicked.connect(
                                lambda p=plugin_instance: p.execute(
                                    self.log_console.append,  # Meneruskan metode append log konsol
                                    self.progress.setValue,   # Meneruskan metode setValue progress bar
                                    self # Meneruskan instans aplikasi utama (FRPBypassTool) ke plugin
                                )
                            )
                            self.button_layout.addWidget(button) # Tambahkan tombol ke layout utama
                            self.log_console.append(f"✅ Plugin dimuat: {plugin_instance.get_name()}")
                            loaded_count += 1
                except Exception as e:
                    self.log_console.append(f"❌ Gagal memuat plugin '{filename}': {e}")
        self.log_console.append(f"Total {loaded_count} plugin berhasil dimuat.")
        if loaded_count == 0:
            self.log_console.append("Tidak ada plugin ditemukan. Pastikan ada file plugin (.py) di folder 'plugins/'.")


if __name__ == "__main__":
    # Ini adalah titik masuk utama aplikasi
    app = QApplication(sys.argv) # Membuat instans QApplication
    window = FRPBypassTool()     # Membuat instans jendela utama aplikasi
    window.show()                # Menampilkan jendela
    sys.exit(app.exec_())        # Memulai event loop aplikasi
