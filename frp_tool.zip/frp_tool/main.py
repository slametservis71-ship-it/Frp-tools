import sys
import os
import importlib.util
import traceback # Import untuk mencetak stack trace error

from PyQt5.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QTextEdit, QLabel, QGroupBox,
    QProgressBar, QGridLayout, QFileDialog
)
from PyQt5.QtGui import QFont, QColor
from PyQt5.QtCore import QTimer, Qt

# --- Penting: Impor modul dari folder utama ---
# Pastikan device_detector.py dan folder plugins/ ada di direktori yang sama dengan main.py
try:
    from plugin_interface import FRPToolPlugin
    from device_detector import DeviceDetector
except ImportError as e:
    print(f"Error importing core modules: {e}")
    print("Pastikan 'plugin_interface.py' dan 'device_detector.py' ada di folder yang sama dengan 'main.py'.")
    sys.exit(1)


class FRPBypassTool(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("FRP Bypass Tool - Teknisi HP")
        self.setGeometry(100, 100, 950, 700) # Sedikit perbesar window lagi

        self.device_detector = DeviceDetector()

        main_layout = QVBoxLayout()
        self.setLayout(main_layout)

        # Header Aplikasi
        header = QLabel("📱 FRP BYPASS TOOL")
        header.setFont(QFont("Arial", 16, QFont.Bold))
        header.setAlignment(Qt.AlignCenter)
        header.setStyleSheet("color: #333; padding: 10px;")
        main_layout.addWidget(header)

        # --- Panel Status Koneksi Port ---
        status_panel_box = QGroupBox("🔌 Status Koneksi Port")
        status_panel_box.setFont(QFont("Arial", 11, QFont.Bold))
        status_panel_layout = QGridLayout()
        status_panel_box.setLayout(status_panel_layout)
        status_panel_box.setStyleSheet("QGroupBox { border: 1px solid #ddd; border-radius: 5px; margin-top: 10px; }"
                                       "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top center; padding: 0 5px; }")
        main_layout.addWidget(status_panel_box)

        # Label untuk setiap mode koneksi
        self.status_labels = {}
        modes = ["ADB", "Fastboot", "Download Mode", "MTP", "Qualcomm 9008", "Modem Mode"]
        for i, mode in enumerate(modes):
            label = QLabel(f"{mode}: Tidak Terhubung")
            label.setFont(QFont("Arial", 10, QFont.Bold))
            label.setStyleSheet("color: gray;")
            self.status_labels[mode] = label
            status_panel_layout.addWidget(label, i // 2, i % 2) # Atur dalam 2 kolom

        # --- Informasi Perangkat Utama ---
        info_box = QGroupBox("🔍 Detail Perangkat")
        info_box.setFont(QFont("Arial", 11, QFont.Bold))
        info_layout = QVBoxLayout()
        info_box.setLayout(info_layout)
        info_box.setStyleSheet("QGroupBox { border: 1px solid #ddd; border-radius: 5px; margin-top: 10px; }"
                               "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top center; padding: 0 5px; }")
        main_layout.addWidget(info_box)

        self.device_info = QLabel("Status: Tidak ada perangkat terhubung")
        self.device_info.setFont(QFont("Arial", 10, QFont.Bold))
        self.device_info.setStyleSheet("color: #0056b3;") # Warna biru untuk status utama
        info_layout.addWidget(self.device_info)

        self.device_details = QLabel("Model: -\nAndroid: -\nFRP: -\nSN: -\nManufacturer: -\nBootloader: -")
        self.device_details.setFont(QFont("Arial", 9))
        self.device_details.setStyleSheet("color: #555;")
        info_layout.addWidget(self.device_details)

        # --- Area Tombol Plugin ---
        self.button_box = QGroupBox("🛠️ Menu Utama")
        self.button_box.setFont(QFont("Arial", 11, QFont.Bold))
        self.button_layout = QHBoxLayout()
        self.button_box.setLayout(self.button_layout)
        self.button_box.setStyleSheet("QGroupBox { border: 1px solid #ddd; border-radius: 5px; margin-top: 10px; }"
                                      "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top center; padding: 0 5px; }")
        main_layout.addWidget(self.button_box)

        # --- Progress Bar ---
        self.progress_box = QGroupBox("⏳ Progres Proses")
        self.progress_box.setFont(QFont("Arial", 11, QFont.Bold))
        self.progress_layout = QVBoxLayout()
        self.progress_box.setLayout(self.progress_layout)
        self.progress_box.setStyleSheet("QGroupBox { border: 1px solid #ddd; border-radius: 5px; margin-top: 10px; }"
                                        "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top center; padding: 0 5px; }")
        main_layout.addWidget(self.progress_box)

        self.progress = QProgressBar()
        self.progress.setTextVisible(True)
        self.progress.setValue(0)
        self.progress.setStyleSheet("QProgressBar { border: 1px solid #ccc; border-radius: 5px; text-align: center; background-color: #f0f0f0; }"
                                    "QProgressBar::chunk { background-color: #4CAF50; border-radius: 5px; }") # Warna hijau
        self.progress_layout.addWidget(self.progress)

        # --- Log Proses ---
        log_box = QGroupBox("📝 Log Proses")
        log_box.setFont(QFont("Arial", 11, QFont.Bold))
        log_layout = QVBoxLayout()
        log_box.setLayout(log_layout)
        log_box.setStyleSheet("QGroupBox { border: 1px solid #ddd; border-radius: 5px; margin-top: 10px; }"
                              "QGroupBox::title { subcontrol-origin: margin; subcontrol-position: top center; padding: 0 5px; }")
        main_layout.addWidget(log_box)

        self.log_console = QTextEdit()
        self.log_console.setReadOnly(True)
        self.log_console.setStyleSheet("background-color: #f8f8f8; border: 1px solid #eee; padding: 5px;")
        log_layout.addWidget(self.log_console)

        # Inisialisasi dan load plugins
        self.load_plugins()

        # Timer untuk deteksi perangkat otomatis
        self.timer = QTimer()
        self.timer.timeout.connect(self.auto_detect_device)
        self.timer.start(1000) # Update setiap 1 detik

        self.log_console.append("Aplikasi siap. Menunggu deteksi perangkat...")

    def auto_detect_device(self):
        """Mendeteksi status perangkat dan memperbarui GUI."""
        device_status = self.device_detector.get_device_info()
        self.device_info.setText(f"Status: {device_status['status']}")
        self.device_details.setText(device_status["details"])

        # Update Panel Status Koneksi Port
        mode_statuses = {
            "ADB": device_status["is_adb"],
            "Fastboot": device_status["is_fastboot"],
            "Download Mode": device_status["is_download_mode"],
            "MTP": device_status["is_mtp"],
            "Qualcomm 9008": device_status["is_qualcomm_9008"],
            "Modem Mode": device_status["is_modem_mode"]
        }

        for mode, is_connected in mode_statuses.items():
            label = self.status_labels[mode]
            if is_connected:
                label.setText(f"{mode}: TERHUBUNG")
                label.setStyleSheet("color: green;")
            else:
                label.setText(f"{mode}: Tidak Terhubung")
                label.setStyleSheet("color: gray;")

    def load_plugins(self):
        """Memuat plugin dari folder 'plugins/'."""
        plugin_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins")

        # --- BARIS DEBUG BARU: VERIFIKASI PATH PLUGINS ---
        print(f"\nDEBUG: Mencoba memuat plugin dari direktori: {plugin_dir}")
        if not os.path.exists(plugin_dir):
            print(f"DEBUG: Direktori '{plugin_dir}' TIDAK DITEMUKAN.")
            self.log_console.append(f"Direktori plugin '{plugin_dir}' TIDAK DITEMUKAN. Proses dibatalkan.")
            # Tidak perlu os.makedirs di sini karena itu akan dilakukan oleh user.
            return # Keluar jika direktori tidak ada

        self.log_console.append(f"Mencari plugin di: {plugin_dir}")
        loaded_count = 0

        # --- BARIS DEBUG BARU: LIST FILE DI FOLDER PLUGINS ---
        files_in_plugin_dir = []
        try:
            files_in_plugin_dir = os.listdir(plugin_dir)
            print(f"DEBUG: File yang ditemukan di '{plugin_dir}': {files_in_plugin_dir}")
            if not files_in_plugin_dir:
                print("DEBUG: Folder plugins terlihat KOSONG.")
        except Exception as e:
            print(f"DEBUG: Error saat membaca direktori plugins: {e}")
            self.log_console.append(f"❌ Error saat membaca direktori plugins: {e}")


        for filename in files_in_plugin_dir:
            # --- BARIS DEBUG BARU: FILE YANG DIPROSES ---
            print(f"DEBUG: Memproses file: {filename}")

            if filename.endswith(".py") and filename != "__init__.py":
                module_name = filename[:-3]
                file_path = os.path.join(plugin_dir, filename)

                try:
                    spec = importlib.util.spec_from_file_location(module_name, file_path)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)

                    found_plugin_class = False # Debug flag
                    for item_name in dir(module):
                        item = getattr(module, item_name)
                        # Pastikan item adalah class, turunan dari FRPToolPlugin, dan bukan FRPToolPlugin itu sendiri
                        if isinstance(item, type) and issubclass(item, FRPToolPlugin) and item is not FRPToolPlugin:
                            plugin_instance = item()
                            button = plugin_instance.create_button(self)

                            def create_executor(p_inst):
                                return lambda: p_inst.execute(
                                    self.log_console.append,
                                    self.progress.setValue,
                                    self
                                )
                            button.clicked.connect(create_executor(plugin_instance))
                            self.button_layout.addWidget(button)
                            self.log_console.append(f"✅ Plugin dimuat: {plugin_instance.get_name()}")
                            loaded_count += 1
                            found_plugin_class = True # Set flag
                            # --- BARIS DEBUG BARU: PLUGIN CLASS DITEMUKAN ---
                            print(f"DEBUG: Kelas plugin '{item_name}' ditemukan di '{filename}'.")
                            # Tidak perlu break, agar bisa menemukan lebih dari satu kelas plugin per file (meskipun jarang)

                    if not found_plugin_class:
                        print(f"DEBUG: Tidak ada kelas plugin yang valid (turunan FRPToolPlugin) ditemukan di '{filename}'.")
                except Exception as e:
                    self.log_console.append(f"❌ Gagal memuat plugin '{filename}': {e}")
                    # --- BARIS DEBUG BARU: DETAIL ERROR SAAT MEMUAT PLUGIN ---
                    print(f"DEBUG: Error lengkap memuat '{filename}': {e}")
                    traceback.print_exc() # Cetak stack trace lengkap untuk debug

        self.log_console.append(f"Total {loaded_count} plugin berhasil dimuat.")
        if loaded_count == 0:
            self.log_console.append("Tidak ada plugin ditemukan. Pastikan ada file plugin (.py) di folder 'plugins/'.")
        print("\nDEBUG: Proses pemuatan plugin selesai.") # Debug final


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FRPBypassTool()
    window.show()
    sys.exit(app.exec_())

