@echo off
REM Navigasi ke direktori tempat skrip ini berada
cd /d "%~dp0"

REM Pastikan Python terinstal dan bisa diakses dari PATH
REM Jika tidak, Anda mungkin perlu menentukan path lengkap ke python.exe, contoh:
REM "C:\Python39\python.exe" main.py

echo Menjalankan FRP Bypass Tool...
python main.py

echo.
echo Tekan tombol apapun untuk menutup...
pause >nul
