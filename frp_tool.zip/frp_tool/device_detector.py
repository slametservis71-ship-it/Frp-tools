# device_detector.py
import subprocess
import sys
import platform
import os
import re # Tambahkan import re

# Hanya impor win32com.client jika OS adalah Windows
if sys.platform == "win32":
    try:
        import win32com.client
    except ImportError:
        print("Warning: 'pywin32' library not found. MTP/Download Mode/Qualcomm 9008/Modem Mode detection on Windows might be limited.")
        print("Please install it using: pip install pywin32")
        win32com = None # Set to None so we can check for it later


class DeviceDetector:
    """Class to detect the status of connected devices."""

    def _run_command(self, cmd, timeout=3):
        """Helper function to run subprocess commands and handle errors."""
        try:
            # decode(errors='ignore') to avoid decoding errors for non-UTF characters.
            # stderr=subprocess.PIPE to capture error output.
            # startupinfo for Windows to hide the console window.
            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE

            result = subprocess.check_output(
                cmd,
                timeout=timeout,
                stderr=subprocess.PIPE,
                startupinfo=startupinfo # Apply startupinfo for Windows
            ).decode(errors='ignore').strip()
            return result
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError) as e:
            # print(f"DEBUG: Error executing {cmd}: {e}") # Uncomment for deeper debugging
            return None
        except Exception as e:
            # print(f"DEBUG: Unexpected error executing {cmd}: {e}") # Uncomment for deeper debugging
            return None

    def detect_adb(self):
        """Detects if a device is connected in ADB mode."""
        result = self._run_command(["adb", "devices"])
        # ADB returns a list of devices, if there's more than 1 line (header + device), it's detected.
        # Ensure "device" string is present to confirm device status.
        return result and len(result.strip().splitlines()) > 1 and "device" in result

    def detect_fastboot(self):
        """Detects if a device is connected in Fastboot mode."""
        result = self._run_command(["fastboot", "devices"])
        # Fastboot devices also returns a line if a device is present.
        return bool(result)

    def get_fastboot_info(self):
        """Retrieves bootloader information when in Fastboot mode."""
        info = {
            "bootloader_status": "Unknown",
            "product": "Unknown",
            "variant": "Unknown"
        }
        result = self._run_command(["fastboot", "getvar", "all"], timeout=5) # Longer timeout for getvar all
        if result:
            for line in result.splitlines():
                if "bootloader:" in line and "unlocked" in line:
                    info["bootloader_status"] = "Unlocked"
                elif "bootloader:" in line and "locked" in line:
                    info["bootloader_status"] = "Locked"
                elif "product:" in line:
                    info["product"] = line.split("product:")[1].strip()
                elif "variant:" in line:
                    info["variant"] = line.split("variant:")[1].strip()
        return info

    def detect_mtp(self):
        """Detects if a device is connected in MTP mode."""
        if sys.platform == "win32" and win32com:
            try:
                wmi = win32com.client.GetObject("winmgmts:")
                for usb in wmi.InstancesOf("Win32_PnPEntity"):
                    pnp_id = usb.PNPDeviceID.upper() if usb.PNPDeviceID else ""
                    name = usb.Name.upper() if usb.Name else ""

                    # Cek umum untuk nama MTP/Portable Device
                    if name and ("MTP" in name or "PORTABLE DEVICE" in name):
                        return True
                    
                    # Cek spesifik untuk Samsung MTP/ADB PID (6860)
                    # Berdasarkan Hardware ID yang Anda berikan: USB\VID_04E8&PID_6860...
                    if "VID_04E8" in pnp_id and "PID_6860" in pnp_id:
                        # Konfirmasi lebih lanjut dengan nama atau bagian dari PnP ID
                        if "MTP" in name or "MS_COMP_MTP" in pnp_id or "SAMSUNG_ANDROID" in pnp_id:
                            return True
            except Exception:
                pass
            return False
        elif sys.platform.startswith("linux"):
            try:
                # mtp-detect returns non-zero exit code if no MTP device is found.
                subprocess.check_output(["mtp-detect"], timeout=3, stderr=subprocess.PIPE)
                return True
            except (subprocess.CalledProcessError, FileNotFoundError):
                return False
            except Exception:
                return False
        return False # Fallback for non-Windows/Linux or if win32com is not available

    def detect_download_mode(self):
        """Detects if a Samsung device is in Download Mode (Windows specific)."""
        if sys.platform == "win32" and win32com:
            try:
                wmi = win32com.client.GetObject("winmgmts:")
                for usb in wmi.InstancesOf("Win32_PnPEntity"):
                    pnp_id = usb.PNPDeviceID.upper() if usb.PNPDeviceID else ""
                    name = usb.Name.upper() if usb.Name else ""

                    # Vendor ID Samsung adalah wajib untuk Download Mode.
                    if "VID_04E8" in pnp_id:
                        # *** PERBAIKAN PENTING: ABAIKAN PID_6860 (MTP/ADB) DI SINI ***
                        if "PID_6860" in pnp_id:
                            continue # Lewati perangkat ini karena ini adalah komponen MTP/ADB

                        # PID utama untuk Samsung Download Mode (Odin Mode). Ini sangat spesifik.
                        if "PID_685D" in pnp_id or "PID_685E" in pnp_id: # PID umum Odin mode
                            return True
                        
                        # PID sekunder yang kadang muncul, tapi butuh konfirmasi nama yang lebih jelas
                        if "PID_6601" in pnp_id: # Beberapa model lama/spesifik
                             if "DOWNLOAD" in name or "MODEM" in name or "CDC" in name: # Harus cocok dengan nama yang kuat
                                return True
                        
                        # Nama eksplisit yang hampir secara eksklusif untuk Download Mode
                        # Ini seharusnya hanya diperiksa jika PID bukan 6860.
                        if "SAMSUNG MOBILE USB CDC COMPOSITE DEVICE" in name or \
                           "SAMSUNG MOBILE USB MODEM" in name or \
                           "SAMSUNG USB SERIAL PORT" in name or \
                           "SAMSUNG ANDROID USB MODEM" in name:
                            return True
                        
                        # Pengecekan terakhir: jika "DOWNLOAD" secara eksplisit ada di nama DAN itu adalah VID Samsung.
                        if "DOWNLOAD" in name:
                            return True
            except Exception:
                pass
            return False
        return False

    def detect_qualcomm_9008(self):
        """Detects if a device is in Qualcomm 9008 mode (EDL mode)."""
        if sys.platform == "win32" and win32com:
            try:
                wmi = win32com.client.GetObject("winmgmts:")
                for usb in wmi.InstancesOf("Win32_PnPEntity"):
                    pnp_id = usb.PNPDeviceID.upper() if usb.PNPDeviceID else ""
                    name = usb.Name.upper() if usb.Name else ""
                    # Common VID/PID for Qualcomm 9008 mode.
                    if (
                        "VID_05C6&PID_9008" in pnp_id or
                        "VID_05C6&PID_9006" in pnp_id or
                        "VID_0000&PID_0000" in pnp_id # Sometimes after generic driver install
                    ):
                        if ("QUALCOMM HS-USB QDLOADER 9008" in name or
                            "QUSB_BULK" in name or
                            "USB SERIAL DEVICE" in name): # Generic after driver install
                            return True
            except Exception:
                pass
            return False
        elif sys.platform.startswith("linux"):
            try:
                lsusb_output = self._run_command(["lsusb"])
                if lsusb_output and ("05c6:9008" in lsusb_output or "05c6:9006" in lsusb_output):
                    return True
            except Exception:
                pass
            return False
        return False

    def detect_modem_mode(self):
        """
        Detects if a phone-related modem/serial port is connected.
        More specific than just "modem" to avoid generic system modems or other devices.
        """
        if sys.platform == "win32" and win32com:
            try:
                wmi = win32com.client.GetObject("winmgmts:")
                for usb in wmi.InstancesOf("Win32_PnPEntity"):
                    pnp_id = usb.PNPDeviceID.upper() if usb.PNPDeviceID else ""
                    name = usb.Name.upper() if usb.Name else ""

                    # Lewati jika itu perangkat Samsung (VID_04E8), karena sudah ditangani secara spesifik
                    # oleh detect_download_mode atau itu adalah ADB/MTP dengan komponen modem.
                    if "VID_04E8" in pnp_id:
                        continue 
                    
                    # Lewati jika itu Qualcomm 9008, ditangani secara terpisah
                    if "VID_05C6&PID_9008" in pnp_id or "VID_05C6&PID_9006" in pnp_id:
                        continue

                    # Cek untuk VID perangkat seluler umum yang biasanya mengekspos port modem/serial
                    common_mobile_vids = ["VID_18D1", "VID_1004", "VID_12D1", "VID_0BB4", "VID_0FCE", "VID_22B8", "VID_0421"] # Google, LG, Huawei, HTC, Sony, Motorola, Nokia

                    is_mobile_device_vid = False
                    for vid in common_mobile_vids:
                        if vid in pnp_id:
                            is_mobile_device_vid = True
                            break
                    
                    if is_mobile_device_vid:
                        # Jika itu VID perangkat seluler, cari nama terkait modem/serial/diag
                        if ("MODEM" in name or "DIAG" in name or "SERIAL" in name or "CDC" in name or "COM" in name):
                            # Saring lebih lanjut: hindari COM/SERIAL generik jika tidak jelas terkait seluler
                            if "COM" in name and not any(brand in name for brand in ["ANDROID", "LG", "HUAWEI", "QUALCOMM", "HTC", "SONY", "MOTOROLA", "ZTE", "NOKIA"]):
                                continue 
                            return True
                    
                    # Fallback untuk port modem/serial "Android" spesifik jika VID tidak ada di common_mobile_vids
                    # Pastikan itu bukan antarmuka ADB Composite yang bukan modem sungguhan.
                    if "ANDROID" in name and ("MODEM" in name or "SERIAL" in name or "CDC" in name) and "COMPOSITE ADB INTERFACE" not in name:
                        return True

            except Exception:
                pass
            return False
        elif sys.platform.startswith("linux"):
            try:
                lsusb_output = self._run_command(["lsusb"])
                if lsusb_output and ("CDC Abstract Control Model" in lsusb_output or "Modem" in lsusb_output):
                    return True
                # Cek umum untuk keberadaan ttyUSB/ttyACM di Linux.
                if os.path.exists("/dev/ttyUSB0") or os.path.exists("/dev/ttyACM0"):
                    return True
            except Exception:
                pass
            return False
        return False

    def get_device_info(self):
        """Gathers and returns detected device information."""
        info = {
            "status": "No device connected",
            "details": "Model: -\nAndroid: -\nFRP: -\nSN: -\nManufacturer: -\nBootloader: -",
            "mode": "none",
            "model": "Unknown",
            "android_version": "Unknown",
            "frp_status": "Unknown",
            "serial_number": "Unknown",
            "manufacturer": "Unknown",
            "bootloader_status": "Unknown",
            # Connection status for the new panel
            "is_adb": False,
            "is_fastboot": False,
            "is_download_mode": False,
            "is_mtp": False,
            "is_qualcomm_9008": False,
            "is_modem_mode": False
        }

        # Prioritaskan deteksi untuk status utama dan detail.
        # Urutan penting di sini! MTP harus diperiksa SEBELUM Download Mode untuk Samsung.

        is_adb_detected = self.detect_adb()
        is_fastboot_detected = self.detect_fastboot()
        is_mtp_detected = self.detect_mtp() # Periksa MTP di awal
        is_qualcomm_9008_detected = self.detect_qualcomm_9008()
        is_download_mode_detected = self.detect_download_mode() # Periksa Download Mode setelah MTP
        is_modem_mode_detected = self.detect_modem_mode() # Mode modem generik terakhir


        # Perbarui semua status koneksi individual terlebih dahulu
        info["is_adb"] = is_adb_detected
        info["is_fastboot"] = is_fastboot_detected
        info["is_download_mode"] = is_download_mode_detected
        info["is_mtp"] = is_mtp_detected
        info["is_qualcomm_9008"] = is_qualcomm_9008_detected
        info["is_modem_mode"] = is_modem_mode_detected

        # Kemudian tentukan mode utama yang terdeteksi dan detailnya berdasarkan prioritas
        if is_adb_detected:
            info["status"] = "Device detected via ADB"
            info["mode"] = "adb"
            try:
                info["model"] = self._run_command(["adb", "shell", "getprop", "ro.product.model"]) or "Unknown"
                info["android_version"] = self._run_command(["adb", "shell", "getprop", "ro.build.version.release"]) or "Unknown"
                info["serial_number"] = self._run_command(["adb", "get-serialno"]) or "Unknown"
                info["manufacturer"] = self._run_command(["adb", "shell", "getprop", "ro.product.manufacturer"]) or "Unknown"

                # Deteksi status FRP melalui ADB
                frp_prop = self._run_command(["adb", "shell", "getprop", "ro.frp.pst"])
                if frp_prop == "1":
                    info["frp_status"] = "Likely ON"
                elif frp_prop == "0":
                    info["frp_status"] = "Likely OFF"
                else:
                    frp_prop_alt = self._run_command(["adb", "shell", "getprop", "ro.vendor.frp.pst"])
                    if frp_prop_alt == "1":
                        info["frp_status"] = "Likely ON"
                    elif frp_prop_alt == "0":
                        info["frp_status"] = "Likely OFF"

                info["details"] = (
                    f"Model: {info['model']}\n"
                    f"Android: {info['android_version']}\n"
                    f"FRP: {info['frp_status']}\n"
                    f"SN: {info['serial_number']}\n"
                    f"Manufacturer: {info['manufacturer']}"
                )
            except Exception as e:
                # Tangani kesalahan selama pengambilan detail ADB, tapi jangan sampai crash
                info["status"] = "ADB device detected, failed to get full info"
                info["details"] = f"Error retrieving details: {e}"

        elif is_fastboot_detected:
            info["status"] = "Device in Fastboot mode"
            info["mode"] = "fastboot"
            fastboot_details = self.get_fastboot_info()
            info["bootloader_status"] = fastboot_details["bootloader_status"]
            info["details"] = (
                f"Model: {fastboot_details['product'] if fastboot_details['product'] != 'Unknown' else '-'}\n"
                f"Android: -\nFRP: -\nSN: -\nManufacturer: -\n"
                f"Bootloader: {info['bootloader_status']}"
            )
        elif is_mtp_detected: # MTP sekarang memiliki prioritas lebih tinggi dari Download/Modem jika terdeteksi
            info["status"] = "Device in MTP mode"
            info["mode"] = "mtp"
            info["details"] = "Mode: MTP (Media Transfer Protocol)"
            # Catatan: Mode MTP biasanya tidak mengizinkan pengambilan Model, Android, dll. melalui perintah shell ADB.
            # Jadi, detail ini mungkin tetap 'Unknown' dalam mode MTP kecuali metode lain diterapkan.
        elif is_qualcomm_9008_detected:
            info["status"] = "Device in Qualcomm 9008 mode"
            info["mode"] = "qualcomm_9008"
            info["details"] = "Mode: Qualcomm QDLoader 9008"
        elif is_download_mode_detected:
            info["status"] = "Device in Download Mode (Samsung)"
            info["mode"] = "download"
            info["details"] = "Mode: Download Mode (Odin/EDL)"
        elif is_modem_mode_detected: 
            info["status"] = "Device in Modem Mode"
            info["mode"] = "modem"
            info["details"] = "Mode: Modem (Port COM Terdeteksi)"

        # Jika tidak ada mode spesifik yang terhubung, kembali ke status umum
        if not any([info["is_adb"], info["is_fastboot"], info["is_download_mode"],
                    info["is_mtp"], info["is_qualcomm_9008"], info["is_modem_mode"]]):
            info["status"] = "No device connected"
            info["details"] = "Model: -\nAndroid: -\nFRP: -\nSN: -\nManufacturer: -\nBootloader: -"


        return info

# Contoh penggunaan skrip ini (hanya berjalan saat file ini dieksekusi langsung)
if __name__ == "__main__":
    detector = DeviceDetector()
    info = detector.get_device_info()
    print("--- Device Detection Status ---")
    print(f"Status: {info['status']}")
    print(f"Details:\n{info['details']}")
    print(f"Primary Mode: {info['mode']}")

    print("\n--- Individual Detection Results (for GUI panel) ---")
    print(f"ADB detected: {info['is_adb']}")
    print(f"Fastboot detected: {info['is_fastboot']}")
    print(f"MTP detected: {info['is_mtp']}")
    print(f"Download Mode detected: {info['is_download_mode']}")
    print(f"Qualcomm 9008 detected: {info['is_qualcomm_9008']}")
    print(f"Modem Mode detected: {info['is_modem_mode']}")

