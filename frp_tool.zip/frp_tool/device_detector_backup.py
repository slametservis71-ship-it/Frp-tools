# device_detector.py
import subprocess
import sys

# win32com.client hanya tersedia di Windows.
# Baris ini akan diimpor hanya jika sistem operasinya adalah Windows.
if sys.platform == "win32":
    import win32com.client

class DeviceDetector:
    """Kelas untuk mendeteksi status perangkat yang terhubung."""

    def detect_adb(self):
        """Mendeteksi apakah perangkat terhubung dalam mode ADB."""
        try:
            # Menggunakan 'adb devices' untuk deteksi dasar.
            # decode(errors='ignore') untuk menghindari error decoding karakter.
            result = subprocess.check_output(["adb", "devices"], timeout=3).decode(errors='ignore')
            # Memastikan ada baris selain header "List of devices attached"
            # dan kata "device" ada di output, menandakan perangkat terhubung dengan benar.
            return len(result.strip().splitlines()) > 1 and "device" in result
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            # Tangani jika perintah adb tidak ditemukan, timeout, atau error saat eksekusi.
            return False
        except Exception:
            # Tangani error umum lainnya.
            return False

    def detect_fastboot(self):
        """Mendeteksi apakah perangkat terhubung dalam mode Fastboot."""
        try:
            # decode(errors='ignore') untuk menghindari error decoding karakter.
            result = subprocess.check_output(["fastboot", "devices"], timeout=3).decode(errors='ignore')
            # Jika ada output, berarti ada perangkat fastboot yang terhubung.
            return bool(result.strip())
        except (subprocess.CalledProcessError, subprocess.TimeoutExpired, FileNotFoundError):
            # Tangani jika perintah fastboot tidak ditemukan, timeout, atau error saat eksekusi.
            return False
        except Exception:
            # Tangani error umum lainnya.
            return False

    def detect_mtp(self):
        """Mendeteksi apakah perangkat terhubung dalam mode MTP (khusus Windows)."""
        # Lewati jika bukan sistem operasi Windows.
        if sys.platform != "win32":
            return False
        try:
            # Inisialisasi objek WMI untuk mengakses informasi perangkat.
            wmi = win32com.client.GetObject("winmgmts:")
            # Iterasi melalui semua perangkat Plug-and-Play (PnPEntity).
            for usb in wmi.InstancesOf("Win32_PnPEntity"):
                # Cek jika ada nama perangkat dan mengandung "MTP" atau "PORTABLE DEVICE" (tidak case-sensitive).
                if usb.Name and ("MTP" in usb.Name.upper() or "PORTABLE DEVICE" in usb.Name.upper()):
                    return True
            return False
        except Exception:
            # Tangani error saat mengakses WMI atau properti USB.
            return False

    def detect_download_mode(self):
        """Mendeteksi apakah perangkat Samsung terhubung dalam Download Mode (khusus Windows)."""
        # Lewati jika bukan sistem operasi Windows.
        if sys.platform != "win32":
            return False
        try:
            # Inisialisasi objek WMI untuk mengakses informasi perangkat.
            wmi = win32com.client.GetObject("winmgmts:")
            # Iterasi melalui semua perangkat Plug-and-Play (PnPEntity).
            for usb in wmi.InstancesOf("Win32_PnPEntity"):
                # Periksa Product ID (VID) Samsung (04E8) dan beberapa deskripsi umum.
                if usb.PNPDeviceID and "VID_04E8" in usb.PNPDeviceID.upper():
                    if usb.Name and ("MODEM" in usb.Name.upper() or
                                      "DOWNLOAD" in usb.Name.upper() or
                                      "SAMSUNG USB MOBILE" in usb.Name.upper()):
                        return True
            return False
        except Exception:
            # Tangani error saat mengakses WMI atau properti USB.
            return False

    def get_device_info(self):
        """Mengumpulkan dan mengembalikan informasi perangkat yang terdeteksi."""
        # Prioritaskan deteksi ADB karena memberikan informasi paling lengkap.
        if self.detect_adb():
            try:
                # Mengambil model dan versi Android via ADB shell.
                # decode(errors='ignore') untuk menghindari error decoding karakter.
                model = subprocess.check_output(["adb", "shell", "getprop", "ro.product.model"], timeout=3).decode(errors='ignore').strip()
                android = subprocess.check_output(["adb", "shell", "getprop", "ro.build.version.release"], timeout=3).decode(errors='ignore').strip()
                
                frp_status = "Tidak Diketahui"
                try:
                    # Mencoba beberapa properti FRP yang umum.
                    # decode(errors='ignore') untuk menghindari error decoding karakter.
                    frp_prop = subprocess.check_output(["adb", "shell", "getprop", "ro.frp.pst"], timeout=3).decode(errors='ignore').strip()
                    if frp_prop == "1":
                        frp_status = "Kemungkinan ON"
                    elif frp_prop == "0":
                        frp_status = "Kemungkinan OFF"
                    else:
                        # Coba properti alternatif jika yang pertama tidak valid.
                        frp_prop_alt = subprocess.check_output(["adb", "shell", "getprop", "ro.vendor.frp.pst"], timeout=3).decode(errors='ignore').strip()
                        if frp_prop_alt == "1":
                            frp_status = "Kemungkinan ON"
                        elif frp_prop_alt == "0":
                            frp_status = "Kemungkinan OFF"
                except:
                    pass # Abaikan jika properti FRP tidak ditemukan atau error.

                return {
                    "status": "Perangkat terdeteksi via ADB",
                    "details": f"Model: {model if model else 'Tidak diketahui'}\nAndroid: {android if android else 'Tidak diketahui'}\nFRP: {frp_status}",
                    "mode": "adb"
                }
            except (subprocess.CalledProcessError, subprocess.TimeoutExpired, Exception) as e:
                # Tangani error jika perangkat terdeteksi ADB tetapi gagal mengambil informasinya.
                return {
                    "status": "Perangkat ADB terdeteksi, gagal ambil info",
                    "details": f"Error mengambil detail: {e}",
                    "mode": "adb"
                }
        elif self.detect_fastboot():
            return {
                "status": "Perangkat dalam mode Fastboot",
                "details": "Model: -\nAndroid: -\nFRP: -",
                "mode": "fastboot"
            }
        elif self.detect_download_mode():
            return {
                "status": "Perangkat dalam Download Mode (Samsung)",
                "details": "Model: -\nAndroid: -\nFRP: -",
                "mode": "download"
            }
        elif self.detect_mtp():
            return {
                "status": "Perangkat dalam mode MTP",
                "details": "Model: -\nAndroid: -\nFRP: -",
                "mode": "mtp"
            }
        else:
            return {
                "status": "Tidak ada perangkat terhubung",
                "details": "Model: -\nAndroid: -\nFRP: -",
                "mode": "none"
            }

# Contoh penggunaan script ini (hanya dijalankan saat file ini dieksekusi langsung)
if __name__ == "__main__":
    detector = DeviceDetector()
    info = detector.get_device_info()
    print("--- Status Deteksi Perangkat ---")
    print(f"Status: {info['status']}")
    print(f"Detail:\n{info['details']}")
    print(f"Mode: {info['mode']}")

    print("\n--- Hasil Deteksi Individual (untuk debugging) ---")
    print(f"ADB terdeteksi: {detector.detect_adb()}")
    print(f"Fastboot terdeteksi: {detector.detect_fastboot()}")
    print(f"MTP terdeteksi: {detector.detect_mtp()}")
    print(f"Download Mode terdeteksi: {detector.detect_download_mode()}")
