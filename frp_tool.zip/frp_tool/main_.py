# main.py
from PyQt5.QtWidgets import QApplication, QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QTextEdit, QFileDialog, QLabel, QGroupBox, QProgressBar
from PyQt5.QtGui import QFont
from PyQt5.QtCore import QTimer
import sys, os
import importlib.util

# --- Penting: Impor modul dari folder utama ---
from plugin_interface import FRPToolPlugin
from device_detector import DeviceDetector

class FRPBypassTool(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("FRP Bypass Tool - Teknisi HP")
        self.setGeometry(100, 100, 900, 600)

        self.device_detector = DeviceDetector()

        layout = QVBoxLayout()
        self.setLayout(layout)

        header = QLabel("📱 FRP BYPASS TOOL")
        header.setFont(QFont("Arial", 14, QFont.Bold))
        layout.addWidget(header)

        info_box = QGroupBox("🔍 Status Perangkat")
        info_layout = QVBoxLayout()
        self.device_info = QLabel("Tidak ada perangkat terhubung")
        self.device_details = QLabel("Model: -\nAndroid: -\nFRP: -")
        info_layout.addWidget(self.device_info)
        info_layout.addWidget(self.device_details)
        info_box.setLayout(info_layout)
        layout.addWidget(info_box)

        self.button_box = QGroupBox("🛠️ Menu Utama")
        self.button_layout = QHBoxLayout()
        self.button_box.setLayout(self.button_layout)
        layout.addWidget(self.button_box)

        self.progress = QProgressBar()
        self.progress.setTextVisible(True)
        self.progress.setValue(0)
        layout.addWidget(self.progress)

        log_box = QGroupBox("📝 Log Proses")
        log_layout = QVBoxLayout()
        self.log_console = QTextEdit()
        self.log_console.setReadOnly(True)
        log_layout.addWidget(self.log_console)
        log_box.setLayout(log_layout)
        layout.addWidget(log_box)

        self.load_plugins()

        self.timer = QTimer()
        self.timer.timeout.connect(self.auto_detect_device)
        self.timer.start(2000)

        self.log_console.append("Aplikasi siap. Menunggu deteksi perangkat...")

    def auto_detect_device(self):
        device_status = self.device_detector.get_device_info()
        self.device_info.setText(device_status["status"])
        self.device_details.setText(device_status["details"])

    def load_plugins(self):
        plugin_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins")
        if not os.path.exists(plugin_dir):
            os.makedirs(plugin_dir)
            self.log_console.append(f"Direktori plugin '{plugin_dir}' dibuat.")

        self.log_console.append(f"Mencari plugin di: {plugin_dir}")
        loaded_count = 0
        for filename in os.listdir(plugin_dir):
            if filename.endswith(".py") and filename != "__init__.py":
                module_name = filename[:-3]
                file_path = os.path.join(plugin_dir, filename)

                try:
                    spec = importlib.util.spec_from_file_location(module_name, file_path)
                    module = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(module)

                    for item_name in dir(module):
                        item = getattr(module, item_name)
                        if isinstance(item, type) and issubclass(item, FRPToolPlugin) and item is not FRPToolPlugin:
                            plugin_instance = item()

                            # --- BARIS DEBUG (BISA DIHAPUS NANTI JIKA SUDAH BERHASIL) ---
                            print(f"DEBUG: Plugin dimuat: {plugin_instance.get_name()}, Tipe objek: {type(plugin_instance)}")
                            # --- AKHIR BARIS DEBUG ---

                            button = plugin_instance.create_button(self)

                            # --- PERUBAHAN KONEKSI DI SINI ---
                            # Definisikan fungsi lokal untuk memastikan plugin_instance terikat dengan benar
                            def create_executor(p_inst):
                                return lambda: p_inst.execute(
                                    self.log_console.append,
                                    self.progress.setValue,
                                    self
                                )
                            button.clicked.connect(create_executor(plugin_instance))
                            # --- AKHIR PERUBAHAN ---

                            self.button_layout.addWidget(button)
                            self.log_console.append(f"✅ Plugin dimuat: {plugin_instance.get_name()}")
                            loaded_count += 1
                except Exception as e:
                    self.log_console.append(f"❌ Gagal memuat plugin '{filename}': {e}")
        self.log_console.append(f"Total {loaded_count} plugin berhasil dimuat.")
        if loaded_count == 0:
            self.log_console.append("Tidak ada plugin ditemukan. Pastikan ada file plugin (.py) di folder 'plugins/'.")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = FRPBypassTool()
    window.show()
    sys.exit(app.exec_())
