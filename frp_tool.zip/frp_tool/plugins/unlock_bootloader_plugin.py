# plugins/unlock_bootloader_plugin.py
from plugin_interface import FRPToolPlugin
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QWidget, QPushButton, QFileDialog # Pastikan baris ini ada
import subprocess
import time
import traceback # Untuk mencetak detail error

class UnlockBootloaderPlugin(FRPToolPlugin):
    def get_name(self):
        return "Unlock Bootloader"

    def create_button(self, parent_widget: QWidget):
        button = super().create_button(parent_widget)
        button.setStyleSheet("background-color: #ffc107; color: black;") # Warna kuning
        return button

    def execute(self, log_callback, set_progress_callback, main_app_instance):
        log_callback("Memulai proses Unlock Bootloader...")
        set_progress_callback(0)

        # Memulai thread terpisah untuk operasi Fastboot
        self.unlock_thread = UnlockBootloaderThread(log_callback, set_progress_callback, main_app_instance)
        self.unlock_thread.start()

class UnlockBootloaderThread(QThread):
    def __init__(self, log_callback, set_progress_callback, main_app_instance):
        super().__init__()
        self.log_callback = log_callback
        self.set_progress_callback = set_progress_callback
        self.main_app_instance = main_app_instance

    def run(self):
        # Cek apakah perangkat terhubung dalam mode fastboot
        device_info = self.main_app_instance.device_detector.get_device_info()
        if not device_info["is_fastboot"]:
            self.log_callback("❌ Error: Perangkat tidak terhubung dalam mode Fastboot.")
            self.set_progress_callback(0)
            return

        self.log_callback("Perangkat terdeteksi dalam mode Fastboot.")
        self.set_progress_callback(10)
        time.sleep(1)

        # Konfirmasi user karena ini menghapus data
        self.log_callback("⚠️ PERINGATAN: Proses ini akan MENGHAPUS SEMUA DATA di perangkat Anda!")
        self.log_callback("Silakan konfirmasi secara manual di perangkat jika diperlukan.")
        self.log_callback("Menjalankan perintah 'fastboot flashing unlock'...")
        self.set_progress_callback(30)

        try:
            # Perintah fastboot flashing unlock
            process = subprocess.Popen(
                ["fastboot", "flashing", "unlock"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            stdout, stderr = process.communicate(timeout=60) # Beri waktu 60 detik
            self.log_callback(f"Output Fastboot:\n{stdout}")
            if stderr:
                self.log_callback(f"Error Fastboot:\n{stderr}")

            if "okay" in stdout.lower() or "unlocked" in stdout.lower():
                self.log_callback("✅ Bootloader berhasil di-unlock!")
                self.log_callback("Perangkat Anda mungkin akan reboot.")
                self.set_progress_callback(100)
            elif "waiting for any device" in stdout.lower() and not self.main_app_instance.device_detector.detect_fastboot():
                 self.log_callback("❌ Unlock Bootloader gagal: Perangkat terputus atau tidak merespon.")
                 self.set_progress_callback(0)
            else:
                self.log_callback("❌ Unlock Bootloader gagal atau tidak ada konfirmasi.")
                self.log_callback("Pastikan Anda sudah mengizinkan di layar perangkat.")
                self.set_progress_callback(0)

        except FileNotFoundError:
            self.log_callback("❌ Error: ADB/Fastboot tools tidak ditemukan. Pastikan sudah terinstal dan ditambahkan ke PATH.")
            self.set_progress_callback(0)
        except subprocess.TimeoutExpired:
            process.kill()
            stdout, stderr = process.communicate()
            self.log_callback("❌ Unlock Bootloader gagal: Waktu habis (Timeout).")
            self.log_callback(f"Output Fastboot (sebelum timeout):\n{stdout.decode(errors='ignore')}")
            if stderr:
                self.log_callback(f"Error Fastboot (sebelum timeout):\n{stderr.decode(errors='ignore')}")
            self.set_progress_callback(0)
        except Exception as e:
            self.log_callback(f"❌ Terjadi kesalahan tak terduga: {e}")
            traceback.print_exc() # Cetak stack trace ke konsol CMD untuk debugging
            self.set_progress_callback(0)
