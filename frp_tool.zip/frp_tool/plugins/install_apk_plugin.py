# install_apk_plugin.py (atau instal_apk_plugin.py jika Anda mau tetap)
from plugin_interface import FRPToolPlugin
from PyQt5.QtWidgets import (
    QWidget, QPushButton, QFileDialog, QVBoxLayout, QHBoxLayout,
    QLineEdit, QLabel, QMessageBox, QProgressDialog
)
from PyQt5.QtCore import QThread, pyqtSignal, Qt
import subprocess
import os
import sys
import time
import select # Tambahkan import select di sini

# Kelas Thread untuk menjalankan perintah instalasi APK di latar belakang
class InstallApkThread(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    installation_finished_signal = pyqtSignal(bool, str) # bool: success, str: message

    def __init__(self, apk_file, device_detector_instance, parent=None):
        super().__init__(parent)
        self.apk_file = apk_file
        self.detector = device_detector_instance
        print("DEBUG: InstallApkThread: __init__ called.") # DEBUG

    def run(self):
        print("DEBUG: InstallApkThread: run() started.") # DEBUG
        self.log_signal.emit("Memulai instalasi APK...")
        self.progress_signal.emit(5)

        current_device_info = self.detector.get_device_info()
        print(f"DEBUG: InstallApkThread: Device info - ADB: {current_device_info['is_adb']}, MTP: {current_device_info['is_mtp']}") # DEBUG

        # Cek apakah perangkat siap
        if not current_device_info['is_adb'] and not current_device_info['is_mtp']:
            self.installation_finished_signal.emit(False, "Ponsel tidak terhubung dalam mode ADB atau MTP yang sesuai.")
            self.progress_signal.emit(0)
            print("DEBUG: InstallApkThread: Device not ready, returning.") # DEBUG
            return

        if current_device_info['is_mtp'] and not current_device_info['is_adb']:
            self.log_signal.emit("Ponsel terhubung dalam mode MTP. Mencoba instalasi via ADB yang mungkin tersembunyi (Test Mode)...")
            self.progress_signal.emit(10)
            time.sleep(1) # Beri sedikit waktu untuk ADB mendeteksi jika baru aktif
            
            # Cek ulang apakah ADB sudah terdeteksi setelah delay (opsional tapi bisa membantu)
            current_device_info = self.detector.get_device_info()
            if not current_device_info['is_adb']:
                self.log_signal.emit("Peringatan: Perangkat masih belum terdeteksi di ADB setelah Test Mode.")
                print("DEBUG: InstallApkThread: MTP but no ADB after delay.") # DEBUG
        else:
            self.log_signal.emit("Ponsel terhubung dalam mode ADB. Memulai instalasi...")
            print("DEBUG: InstallApkThread: Device detected via full ADB.") # DEBUG


        try:
            cmd = ["adb", "install", self.apk_file]
            print(f"DEBUG: InstallApkThread: Running command: {' '.join(cmd)}") # DEBUG
            
            # Konfigurasi untuk menyembunyikan jendela CMD di Windows
            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE

            self.log_signal.emit(f"Menjalankan perintah: {' '.join(cmd)}")
            self.progress_signal.emit(30)

            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                startupinfo=startupinfo,
                encoding='utf-8'
            )
            print("DEBUG: InstallApkThread: subprocess.Popen called.") # DEBUG

            stdout_lines = []
            stderr_lines = []
            output_buffer_stdout = "" # Buffer for stdout
            output_buffer_stderr = "" # Buffer for stderr

            poller = select.poll()
            poller.register(process.stdout, select.POLLIN)
            poller.register(process.stderr, select.POLLIN)

            while process.poll() is None or poller.poll(0):
                for fd, event in poller.poll(100): # 100ms timeout
                    if fd == process.stdout.fileno():
                        data = process.stdout.read(1)
                        if data:
                            output_buffer_stdout += data
                            if '\n' in output_buffer_stdout:
                                line, output_buffer_stdout = output_buffer_stdout.split('\n', 1)
                                self.log_signal.emit(f"ADB: {line.strip()}")
                                stdout_lines.append(line.strip())
                                self.progress_signal.emit(min(90, self.progress_signal.emitted[0] + 2))
                    elif fd == process.stderr.fileno():
                        data = process.stderr.read(1)
                        if data:
                            output_buffer_stderr += data
                            if '\n' in output_buffer_stderr:
                                line, output_buffer_stderr = output_buffer_stderr.split('\n', 1)
                                self.log_signal.emit(f"ADB Error: {line.strip()}")
                                stderr_lines.append(line.strip())
                                self.progress_signal.emit(min(90, self.progress_signal.emitted[0] + 2))

                # After polling, check if process has finished and there's remaining output
                if process.poll() is not None and not poller.poll(0):
                    # Read any remaining buffered output
                    if output_buffer_stdout:
                        self.log_signal.emit(f"ADB: {output_buffer_stdout.strip()}")
                        stdout_lines.append(output_buffer_stdout.strip())
                    if output_buffer_stderr:
                        self.log_signal.emit(f"ADB Error: {output_buffer_stderr.strip()}")
                        stderr_lines.append(output_buffer_stderr.strip())
                    break # Process finished and no more output

            process.wait() # Ensure process has fully terminated
            print(f"DEBUG: InstallApkThread: subprocess finished with return code {process.returncode}.") # DEBUG

            final_stdout = "\n".join(stdout_lines) # Join with newline for better readability
            final_stderr = "\n".join(stderr_lines) # Join with newline for better readability

            if process.returncode == 0 and "Success" in final_stdout:
                self.installation_finished_signal.emit(True, "APK berhasil diinstal!")
                self.progress_signal.emit(100)
            else:
                self.installation_finished_signal.emit(False, f"Gagal menginstal APK.\nOutput: {final_stdout}\nError: {final_stderr}")
                self.progress_signal.emit(0)

        except FileNotFoundError:
            self.installation_finished_signal.emit(False, "Error: 'adb' tidak ditemukan. Pastikan Android SDK Platform-Tools terinstal dan di PATH.")
            self.progress_signal.emit(0)
            print("DEBUG: InstallApkThread: FileNotFoundError for adb.") # DEBUG
        except Exception as e:
            self.installation_finished_signal.emit(False, f"Terjadi kesalahan tak terduga: {e}")
            self.progress_signal.emit(0)
            print(f"DEBUG: InstallApkThread: Unexpected exception: {e}") # DEBUG
            import traceback
            traceback.print_exc() # Print full traceback
        finally:
            print("DEBUG: InstallApkThread: run() finished.") # DEBUG


# Kelas Plugin Instal APK
class InstallApkPlugin(FRPToolPlugin):
    def __init__(self):
        super().__init__() # Call superclass init if FRPToolPlugin has one (it doesn't, but good practice)
        print("DEBUG: InstallApkPlugin: __init__ called.") # DEBUG

    def get_name(self):
        return "Instal APK"

    def create_button(self, parent_widget: QWidget):
        button = super().create_button(parent_widget)
        button.setStyleSheet("background-color: #28a745; color: white;")
        print("DEBUG: InstallApkPlugin: create_button called.") # DEBUG
        return button

    def execute(self, log_callback, set_progress_callback, main_app_instance):
        print("DEBUG: InstallApkPlugin: execute() called.") # DEBUG
        self.log_callback = log_callback
        self.set_progress_callback = set_progress_callback
        self.main_app_instance = main_app_instance

        self.log_callback("Membuka dialog pemilihan file APK...")
        
        options = QFileDialog.Options()
        options |= QFileDialog.DontUseNativeDialog # <<< BARIS PENTING YANG DITAMBAHKAN INI
        
        apk_file, _ = QFileDialog.getOpenFileName(
            None,
            "Pilih File APK",
            "",
            "APK Files (*.apk);;All Files (*)",
            options=options
        )

        if not apk_file:
            self.log_callback("Pemilihan file APK dibatalkan.")
            self.set_progress_callback(0)
            print("DEBUG: InstallApkPlugin: APK file selection cancelled.") # DEBUG
            return

        if not os.path.exists(apk_file):
            self.log_callback(f"❌ Error: File '{apk_file}' tidak ditemukan.")
            self.set_progress_callback(0)
            QMessageBox.warning(None, "File Tidak Ditemukan", f"File '{apk_file}' tidak ditemukan. Mohon pilih file yang valid.")
            print(f"DEBUG: InstallApkPlugin: APK file not found: {apk_file}") # DEBUG
            return

        self.log_callback(f"File APK dipilih: {os.path.basename(apk_file)}")
        print(f"DEBUG: InstallApkPlugin: APK file selected: {apk_file}") # DEBUG
        
        current_device_info = self.main_app_instance.device_detector.get_device_info()
        print(f"DEBUG: InstallApkPlugin: Device info before thread start - ADB: {current_device_info['is_adb']}, MTP: {current_device_info['is_mtp']}") # DEBUG

        if current_device_info['is_mtp'] and not current_device_info['is_adb']:
            reply = QMessageBox.question(
                None,
                "Konfirmasi Mode",
                "Ponsel terhubung dalam mode MTP. Untuk menginstal APK dengan cara ini, pastikan Anda telah memasukkan *#0*# di dialer ponsel Anda untuk mengaktifkan Test Mode.\n\n"
                "Apakah Anda sudah melakukannya?",
                QMessageBox.Yes | QMessageBox.No,
                QMessageBox.No
            )
            if reply == QMessageBox.No:
                self.log_callback("Instalasi dibatalkan oleh pengguna (instruksi Test Mode belum diikuti).")
                self.set_progress_callback(0)
                print("DEBUG: InstallApkPlugin: MTP confirmation declined.") # DEBUG
                return

        self.install_thread = InstallApkThread(apk_file, self.main_app_instance.device_detector)
        self.install_thread.log_signal.connect(self.log_callback)
        self.install_thread.progress_signal.connect(self.set_progress_callback)
        self.install_thread.installation_finished_signal.connect(self._on_installation_finished)
        
        print("DEBUG: InstallApkPlugin: Connecting progress_signal to progress_dialog.setValue") # DEBUG
        # Initialize progress dialog here, before starting the thread, to avoid blocking issues
        self.progress_dialog = QProgressDialog("Menginstal APK...", "Batalkan", 0, 100, None)
        self.progress_dialog.setWindowModality(Qt.WindowModal)
        self.progress_dialog.setCancelButton(None) # Hide cancel button
        self.progress_dialog.setWindowTitle("Proses Instalasi APK")
        self.progress_dialog.setMinimumDuration(0)
        self.progress_dialog.setValue(0)
        self.progress_dialog.show()
        
        # Connect progress signal to dialog AFTER it's created and shown
        self.install_thread.progress_signal.connect(self.progress_dialog.setValue)
        
        self.install_thread.start()
        print("DEBUG: InstallApkPlugin: InstallApkThread started.") # DEBUG


    def _on_installation_finished(self, success, message):
        print(f"DEBUG: InstallApkPlugin: _on_installation_finished called. Success: {success}, Message: {message}") # DEBUG
        if hasattr(self, 'progress_dialog') and self.progress_dialog.isVisible():
            print("DEBUG: InstallApkPlugin: Closing progress dialog.") # DEBUG
            self.progress_dialog.close()
            
        self.log_callback(f"Status instalasi: {'Berhasil' if success else 'Gagal'}. Pesan: {message}")
        if success:
            QMessageBox.information(None, "Instalasi APK", "APK telah berhasil diinstal.")
        else:
            QMessageBox.critical(None, "Instalasi APK Gagal", message)

