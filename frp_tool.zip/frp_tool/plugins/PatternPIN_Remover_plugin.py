# plugins/PatternPIN_Remover_plugin.py

from PyQt5.QtCore import QObject, pyqtSignal, QThread, Qt
from PyQt5.QtWidgets import QPushButton, QVBoxLayout, QLineEdit, QLabel, QComboBox, QWidget
import importlib.util
import os
import time
from plugin_interface import FRPToolPlugin

class WorkerSignals(QObject):
    """
    Defines the signals available from a running worker thread.
    """
    finished = pyqtSignal(bool, str)
    error = pyqtSignal(str)
    result = pyqtSignal(object)
    progress_updated = pyqtSignal(int)
    status_message = pyqtSignal(str)

class PatternPINActions:
    def __init__(self):
        self.worker_signals = WorkerSignals() # Inisialisasi WorkerSignals di sini
        self.device_detector = None # Device detector akan di-pass saat execute jika diperlukan

    def set_device_detector(self, device_detector):
        """Untuk mengatur device detector dari plugin."""
        self.device_detector = device_detector

    def remove_screen_lock(self, device_id: str, device_module, method_function_name: str, log_signal, progress_callback): # Ganti log_callback dengan log_signal
        """
        Mengorkestrasi proses penghapusan kunci layar untuk perangkat yang dipilih.

        Args:
            device_id (str): ID unik perangkat.
            device_module: Modul perangkat yang berisi fungsi spesifik.
            method_function_name (str): Nama fungsi dalam device_module yang akan dipanggil.
            log_signal (pyqtSignal): Sinyal untuk mengirim pesan log.
            progress_callback (callable): Fungsi untuk memperbarui progres bar.
        """
        log_signal.emit(f"Memulai operasi hapus kunci layar untuk perangkat {device_id} "
                        f"menggunakan metode '{method_function_name}' dari modul '{device_module.__name__}'.")
        self.worker_signals.status_message.emit(f"Memulai hapus kunci layar untuk {device_id}...")
        self.worker_signals.progress_updated.emit(5) # Mulai progres
        progress_callback(5)

        try:
            # Validasi apakah fungsi yang diminta ada di modul perangkat
            if not hasattr(device_module, method_function_name):
                error_msg = f"Fungsi '{method_function_name}' tidak ditemukan di modul {device_module.__name__}."
                print(f"Error: {error_msg}") # Ganti logger
                self.worker_signals.error.emit(error_msg)
                self.worker_signals.operation_finished.emit(False, error_msg)
                return False

            target_function = getattr(device_module, method_function_name)

            # Panggil fungsi spesifik perangkat.
            # Fungsi ini diharapkan akan menangani progress dan status message-nya sendiri
            # atau melaporkan kembali melalui `signals`.
            success = target_function(device_id, self.worker_signals, log_signal, progress_callback) # Ganti log_callback dengan log_signal

            if success:
                final_message = "Kunci layar berhasil dihapus!"
                print(f"Info: Operasi hapus kunci layar untuk {device_id} selesai: {final_message}") # Ganti logger
                self.worker_signals.operation_finished.emit(True, final_message)
            else:
                final_message = "Gagal menghapus kunci layar."
                print(f"Warning: Operasi hapus kunci layar untuk {device_id} gagal: {final_message}") # Ganti logger
                self.worker_signals.operation_finished.emit(False, final_message)

            return success

        except Exception as e:
            error_msg = f"Terjadi kesalahan saat operasi hapus kunci layar: {str(e)}"
            print(f"Exception: {error_msg}") # Ganti logger
            self.worker_signals.error.emit(error_msg)
            self.worker_signals.operation_finished.emit(False, error_msg)
            return False

class PatternPINRemoverPlugin(FRPToolPlugin, QObject): # Tambahkan QObject inheritance
    log_signal = pyqtSignal(str) # Tambahkan sinyal untuk logging

    def __init__(self):
        super().__init__()
        QObject.__init__(self) # Inisialisasi QObject
        self.actions = PatternPINActions()
        self.device_module = None # Akan diisi saat tombol execute ditekan
        self.main_widget = None # Menyimpan widget utama UI plugin
        self.worker_thread = None # Untuk menyimpan instance thread
        self.device_id_input = None # Tambahkan ini
        self.module_combo = None # Tambahkan ini
        self.method_combo = None # Tambahkan ini

    def get_name(self):
        return "Pattern & PIN Remover"

    def create_ui(self, parent_widget):
        self.main_widget = QWidget()
        self.layout = QVBoxLayout()
        self.main_widget.setLayout(self.layout)

        # Label dan Input untuk Device ID
        self.device_id_label = QLabel("Device ID:")
        self.device_id_input = QLineEdit()
        self.layout.addWidget(self.device_id_label)
        self.layout.addWidget(self.device_id_input)

        # Label dan ComboBox untuk Memilih Jenis Chipset/Modul
        self.module_label = QLabel("Pilih Jenis Chipset:")
        self.module_combo = QComboBox()
        self.module_combo.addItem("Universal MTK", "Universal_MTK")
        self.module_combo.addItem("Universal Qualcomm", "Universal_Qualcomm")
        # Tambahkan opsi lain sesuai kebutuhan
        self.layout.addWidget(self.module_label)
        self.layout.addWidget(self.module_combo)

        # Label dan ComboBox untuk Memilih Metode
        self.method_label = QLabel("Pilih Metode:")
        self.method_combo = QComboBox()
        self.method_combo.addItem("Remove Password", "remove_password")
        # Tambahkan opsi lain sesuai dengan fungsi di modul
        self.layout.addWidget(self.method_label)
        self.layout.addWidget(self.method_combo)

        self.execute_button = QPushButton("Mulai Hapus Kunci Layar")
        self.layout.addWidget(self.execute_button)
        self.execute_button.clicked.connect(self.start_execution) # Hubungkan sinyal klik di sini

        return self.main_widget

    def create_button(self, parent):
        button = QPushButton(self.get_name(), parent)
        return button

    def start_execution(self): # Metode ini sekarang akan dipanggil saat tombol di UI plugin diklik
        if self.main_app_instance:
            device_id = self.device_id_input.text()
            selected_module_name = self.module_combo.currentData()
            method_name = self.method_combo.currentData()

            if not device_id:
                self.log_signal.emit("Error: Device ID tidak boleh kosong.")
                return

            plugins_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "plugins")
            module_path = os.path.join(plugins_dir, f"Universal_{selected_module_name}.py") # Asumsi modul ada di folder plugins

            if not os.path.exists(module_path):
                self.log_signal.emit(f"Error: Modul 'Universal_{selected_module_name}.py' tidak ditemukan di folder plugins.")
                return

            spec = importlib.util.spec_from_file_location(selected_module_name, module_path)
            module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(module)
            self.device_module = module # Simpan modul yang dimuat

            self.worker_thread = PatternPINRemoverThread(
                device_id,
                self.device_module,
                method_name,
                self.actions,
                self.log_signal, # Gunakan self.log_signal
                self.main_app_instance.progress.setValue
            )
            self.worker_thread.start()
        else:
            print("Error: Instance aplikasi utama belum diatur.")

    def execute(self, log_callback, set_progress_callback, main_app_instance):
        """Metode execute yang dipanggil oleh main.py saat tombol plugin diklik."""
        self.main_app_instance = main_app_instance # Simpan instance aplikasi utama
        # Hubungkan sinyal logging plugin ke log console aplikasi utama
        self.log_signal.connect(main_app_instance.log_console.append)

class PatternPINRemoverThread(QThread):
    def __init__(self, device_id, device_module, method_name, actions, log_signal, progress_callback): # Ganti log_callback dengan log_signal
        super().__init__()
        self.device_id = device_id
        self.device_module = device_module
        self.method_name = method_name
        self.actions = actions
        self.log_signal = log_signal # Gunakan log_signal
        self.progress_callback = progress_callback

    def run(self):
        self.log_signal.emit(f"Memulai proses hapus kunci layar di thread...")
        self.actions.remove_screen_lock(
            self.device_id,
            self.device_module,
            self.method_name,
            self.log_signal, # Gunakan log_signal
            self.progress_callback
        )