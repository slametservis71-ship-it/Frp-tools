# plugins/enable_adb_plugin.py
from plugin_interface import FRPToolPlugin
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QWidget, QPushButton, QFileDialog # Pastikan baris ini ada
import subprocess
import time
import traceback # Untuk mencetak detail error

class EnableAdbPlugin(FRPToolPlugin):
    def get_name(self):
        return "Enable ADB"

    def create_button(self, parent_widget: QWidget):
        button = super().create_button(parent_widget)
        button.setStyleSheet("background-color: #28a745; color: white;") # Warna hijau
        return button

    def execute(self, log_callback, set_progress_callback, main_app_instance):
        log_callback("Memulai proses Enable ADB...")
        set_progress_callback(0)

        self.enable_adb_thread = EnableAdbThread(log_callback, set_progress_callback, main_app_instance)
        self.enable_adb_thread.start()

class EnableAdbThread(QThread):
    def __init__(self, log_callback, set_progress_callback, main_app_instance):
        super().__init__()
        self.log_callback = log_callback
        self.set_progress_callback = set_progress_callback
        self.main_app_instance = main_app_instance

    def run(self):
        self.log_callback("Mencoba mendeteksi perangkat...")
        self.set_progress_callback(10)
        time.sleep(1)

        # Cek apakah ADB sudah aktif
        device_info = self.main_app_instance.device_detector.get_device_info()
        if device_info["is_adb"]:
            self.log_callback("✅ ADB sudah terhubung dan aktif.")
            self.set_progress_callback(100)
            return

        self.log_callback("ADB belum terhubung. Mencoba mengaktifkan/memicu...")
        self.set_progress_callback(30)

        try:
            # Metode 1: Coba reboot ke mode normal (jika di Fastboot/Recovery)
            # Ini mungkin mengaktifkan ADB di boot normal
            self.log_callback("Mencoba reboot perangkat ke mode normal...")
            # Menggunakan shell=True karena kadang Fastboot butuh ini di beberapa sistem
            result = subprocess.run(
                ["fastboot", "reboot"],
                capture_output=True, text=True, timeout=30
            )
            self.log_callback(f"Output Fastboot reboot: {result.stdout.strip()}")
            if result.stderr:
                self.log_callback(f"Error Fastboot reboot: {result.stderr.strip()}")

            if "rebooting" in result.stdout.lower() or "ok" in result.stdout.lower():
                self.log_callback("Perintah reboot dikirim. Tunggu perangkat booting...")
                self.set_progress_callback(60)
                time.sleep(15) # Beri waktu perangkat untuk boot dan ADB aktif

                # Cek ulang setelah reboot
                if self.main_app_instance.device_detector.detect_adb():
                    self.log_callback("✅ ADB berhasil diaktifkan setelah reboot!")
                    self.set_progress_callback(100)
                    return
                else:
                    self.log_callback("ADB tidak aktif setelah reboot. Mencoba metode lain.")
            else:
                self.log_callback("Perintah reboot fastboot gagal atau perangkat tidak di Fastboot.")

            # Metode 2: Coba aktivasi ADB generik (misal melalui port diagnostik, dll.)
            # Ini sangat tergantung pada model dan firmware
            self.log_callback("Mencoba metode aktivasi ADB generik (memerlukan driver yang tepat)...")
            # Ini hanya placeholder, metode riil sangat spesifik
            self.log_callback("Untuk beberapa perangkat, Anda perlu menekan kode *#0*# atau sejenisnya di dialer")
            self.log_callback("Atau masuk ke Recovery Mode dan pilih 'Apply update from ADB'")
            self.set_progress_callback(80)
            time.sleep(5)

            if self.main_app_instance.device_detector.detect_adb():
                self.log_callback("✅ ADB berhasil diaktifkan (mungkin butuh interaksi manual sebelumnya).")
                self.set_progress_callback(100)
            else:
                self.log_callback("❌ Gagal mengaktifkan ADB secara otomatis. Coba metode manual atau driver.")
                self.set_progress_callback(0)

        except FileNotFoundError:
            self.log_callback("❌ Error: ADB/Fastboot tools tidak ditemukan. Pastikan sudah terinstal dan ditambahkan ke PATH.")
            self.set_progress_callback(0)
        except subprocess.TimeoutExpired:
            self.log_callback("❌ Operasi waktu habis. Perangkat mungkin tidak merespon.")
            self.set_progress_callback(0)
        except Exception as e:
            self.log_callback(f"❌ Terjadi kesalahan tak terduga: {e}")
            traceback.print_exc()
            self.set_progress_callback(0)
