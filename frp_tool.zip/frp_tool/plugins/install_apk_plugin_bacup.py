# plugins/install_apk_plugin.py
from plugin_interface import FRPToolPlugin
from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QWidget, QPushButton, QFileDialog # Pastikan baris ini ada
import subprocess
import time
import os
import traceback # Untuk mencetak detail error

class InstallApkPlugin(FRPToolPlugin):
    def get_name(self):
        return "Install APK"

    def create_button(self, parent_widget: QWidget):
        button = super().create_button(parent_widget)
        button.setStyleSheet("background-color: #6c757d; color: white;") # Warna abu-abu
        return button

    def execute(self, log_callback, set_progress_callback, main_app_instance):
        log_callback("Memulai proses Install APK...")
        set_progress_callback(0)

        # Memilih file APK
        options = QFileDialog.Options()
        file_name, _ = QFileDialog.getOpenFileName(
            main_app_instance,
            "Pilih file APK untuk diinstal",
            "",
            "Android Package (*.apk);;All Files (*)",
            options=options
        )

        if file_name:
            self.install_apk_thread = InstallApkThread(log_callback, set_progress_callback, main_app_instance, file_name)
            self.install_apk_thread.start()
        else:
            log_callback("Instalasi APK dibatalkan: Tidak ada file yang dipilih.")
            set_progress_callback(0)

class InstallApkThread(QThread):
    def __init__(self, log_callback, set_progress_callback, main_app_instance, apk_path):
        super().__init__()
        self.log_callback = log_callback
        self.set_progress_callback = set_progress_callback
        self.main_app_instance = main_app_instance
        self.apk_path = apk_path

    def run(self):
        self.log_callback(f"Mencoba menginstal APK: {os.path.basename(self.apk_path)}")
        self.set_progress_callback(10)
        time.sleep(1)

        # Cek apakah perangkat terhubung dalam mode ADB
        device_info = self.main_app_instance.device_detector.get_device_info()
        if not device_info["is_adb"]:
            self.log_callback("❌ Error: Perangkat tidak terhubung dalam mode ADB.")
            self.set_progress_callback(0)
            return

        self.log_callback("Perangkat terdeteksi via ADB.")
        self.set_progress_callback(30)

        try:
            self.log_callback("Mengirim perintah 'adb install'...")
            process = subprocess.Popen(
                ["adb", "install", self.apk_path],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True
            )

            # Membaca output secara real-time (opsional, tapi bagus untuk feedback)
            output = []
            while True:
                line = process.stdout.readline()
                if line:
                    output.append(line)
                    self.log_callback(f"ADB: {line.strip()}")
                if not line and process.poll() is not None:
                    break
            
            # Juga baca stderr jika ada
            stderr_output = process.stderr.read()
            if stderr_output:
                self.log_callback(f"ADB Error Stream: {stderr_output.strip()}")
                output.append(stderr_output)

            # Menunggu proses selesai dan mendapatkan return code
            process.wait(timeout=120) # Beri waktu lebih lama untuk instalasi APK besar

            full_output = "".join(output)

            if "success" in full_output.lower():
                self.log_callback(f"✅ APK '{os.path.basename(self.apk_path)}' berhasil diinstal!")
                self.set_progress_callback(100)
            elif "already exists" in full_output.lower():
                self.log_callback(f"⚠️ APK '{os.path.basename(self.apk_path)}' sudah terinstal (UPDATE).")
                self.set_progress_callback(100)
            else:
                self.log_callback(f"❌ Instalasi APK '{os.path.basename(self.apk_path)}' gagal.")
                self.log_callback(f"Lihat output ADB di atas untuk detail error.")
                self.set_progress_callback(0)

        except FileNotFoundError:
            self.log_callback("❌ Error: ADB tools tidak ditemukan. Pastikan sudah terinstal dan ditambahkan ke PATH.")
            self.set_progress_callback(0)
        except subprocess.TimeoutExpired:
            process.kill()
            self.log_callback("❌ Instalasi APK waktu habis. Perangkat mungkin tidak merespon atau APK terlalu besar.")
            self.set_progress_callback(0)
        except Exception as e:
            self.log_callback(f"❌ Terjadi kesalahan tak terduga: {e}")
            traceback.print_exc()
            self.set_progress_callback(0)
