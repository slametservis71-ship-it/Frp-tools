# plugins/trigger_app_plugin.py
from plugin_interface import FRPToolPlugin
from PyQt5.QtWidgets import (
    QWidget, QPushButton, QMessageBox, QVBoxLayout, QHBoxLayout, QLabel, QDialog, QProgressDialog
)
from PyQt5.QtCore import QThread, pyqtSignal, Qt
import subprocess
import time
import sys
import threading # BARU: Menggunakan threading untuk membaca output

# Kelas Thread untuk menjalankan perintah ADB di latar belakang
class TriggerAppThread(QThread):
    log_signal = pyqtSignal(str)
    progress_signal = pyqtSignal(int)
    operation_finished_signal = pyqtSignal(bool, str) # bool: success, str: message

    def __init__(self, command_type, device_detector_instance, parent=None):
        super().__init__(parent)
        self.command_type = command_type # 'chrome' atau 'galaxy_store'
        self.detector = device_detector_instance
        self.process = None # BARU: Menyimpan referensi proses
        print(f"DEBUG: TriggerAppThread: __init__ called for {command_type}.")

    # BARU: Fungsi untuk membaca stream (stdout/stderr) di thread terpisah
    def stream_reader(self, stream, error=False):
        prefix = "ADB Error: " if error else "ADB: "
        try:
            for line in iter(stream.readline, ''):
                if line:
                    self.log_signal.emit(f"{prefix}{line.strip()}")
            stream.close()
        except Exception as e:
            print(f"DEBUG: Exception in stream_reader: {e}")

    def run(self):
        print(f"DEBUG: TriggerAppThread: run() started for {self.command_type}.")
        self.log_signal.emit(f"Memulai operasi untuk memicu {self.command_type}...")
        self.progress_signal.emit(5)

        current_device_info = self.detector.get_device_info()
        print(f"DEBUG: TriggerAppThread: Device info - ADB: {current_device_info['is_adb']}, MTP: {current_device_info['is_mtp']}")

        if not current_device_info['is_mtp'] and not current_device_info['is_adb']:
            self.operation_finished_signal.emit(False, "Ponsel tidak terhubung dalam mode MTP atau ADB yang sesuai.")
            self.progress_signal.emit(0)
            print("DEBUG: TriggerAppThread: Device not ready, returning.")
            return

        if current_device_info['is_mtp'] and not current_device_info['is_adb']:
            self.log_signal.emit("Ponsel terhubung dalam mode MTP. Mencoba memicu via ADB yang mungkin tersembunyi (Test Mode)...")
            self.progress_signal.emit(10)
            time.sleep(1)
            
            current_device_info = self.detector.get_device_info()
            if not current_device_info['is_adb']:
                self.log_signal.emit("Peringatan: Perangkat masih belum terdeteksi di ADB setelah Test Mode. Tetap mencoba...")
                print("DEBUG: TriggerAppThread: MTP but no ADB after delay.")
        else:
            self.log_signal.emit("Ponsel terhubung dalam mode ADB. Memicu aplikasi...")
            print("DEBUG: TriggerAppThread: Device detected via full ADB.")
        
        self.progress_signal.emit(20)

        cmd = []
        if self.command_type == 'chrome':
            cmd = ["adb", "shell", "am", "start", "-a", "android.intent.action.VIEW", "-d", "http://www.google.com"]
            self.log_signal.emit("Mengirim perintah untuk membuka Chrome/Browser...")
        elif self.command_type == 'galaxy_store':
            cmd = ["adb", "shell", "am", "start", "-n", "com.sec.android.app.samsungapps/.Main"]
            self.log_signal.emit("Mengirim perintah untuk membuka Galaxy Store...")
        else:
            self.operation_finished_signal.emit(False, "Tipe perintah tidak dikenal.")
            self.progress_signal.emit(0)
            print("DEBUG: TriggerAppThread: Unknown command type.")
            return

        try:
            print(f"DEBUG: TriggerAppThread: Running command: {' '.join(cmd)}")
            
            startupinfo = None
            if sys.platform == "win32":
                startupinfo = subprocess.STARTUPINFO()
                startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
                startupinfo.wShowWindow = subprocess.SW_HIDE

            self.progress_signal.emit(30)

            # DIPERBAIKI: Logika subproses yang lebih robust
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                startupinfo=startupinfo,
                encoding='utf-8',
                errors='ignore' # Mencegah error jika ada karakter aneh
            )
            print("DEBUG: TriggerAppThread: subprocess.Popen called.")
            
            self.progress_signal.emit(50)

            # BARU: Gunakan thread terpisah untuk membaca stdout dan stderr secara real-time
            stdout_thread = threading.Thread(target=self.stream_reader, args=(self.process.stdout, False))
            stderr_thread = threading.Thread(target=self.stream_reader, args=(self.process.stderr, True))
            stdout_thread.daemon = True
            stderr_thread.daemon = True
            stdout_thread.start()
            stderr_thread.start()

            # Tunggu proses selesai
            self.process.wait()

            # Pastikan thread pembaca selesai
            stdout_thread.join()
            stderr_thread.join()
            
            self.progress_signal.emit(90)
            print(f"DEBUG: TriggerAppThread: subprocess finished with return code {self.process.returncode}.")

            # DIPERBAIKI: Pengecekan keberhasilan yang lebih andal
            if self.process.returncode == 0:
                self.operation_finished_signal.emit(True, f"{self.command_type.replace('_', ' ').capitalize()} berhasil dipicu!")
                self.progress_signal.emit(100)
            else:
                # Pesan error dari ADB biasanya ada di stderr, tapi kita sudah log secara real-time.
                # Kita bisa tambahkan pesan umum di sini.
                self.operation_finished_signal.emit(False, f"Gagal memicu {self.command_type.replace('_', ' ')}.\nADB mengembalikan kode error: {self.process.returncode}.\nPeriksa log untuk detail.")
                self.progress_signal.emit(0)

        except FileNotFoundError:
            self.operation_finished_signal.emit(False, "Error: 'adb' tidak ditemukan. Pastikan Android SDK Platform-Tools terinstal dan ada di dalam PATH sistem.")
            self.progress_signal.emit(0)
            print("DEBUG: TriggerAppThread: FileNotFoundError for adb.")
        except Exception as e:
            self.operation_finished_signal.emit(False, f"Terjadi kesalahan tak terduga: {e}")
            self.progress_signal.emit(0)
            print(f"DEBUG: TriggerAppThread: Unexpected exception: {e}")
            import traceback
            traceback.print_exc()
        finally:
            print("DEBUG: TriggerAppThread: run() finished.")

# Dialog untuk memilih antara Chrome atau Galaxy Store (Tidak ada perubahan, sudah baik)
class TriggerAppChoiceDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Pilih Aplikasi")
        self.setFixedSize(300, 150)
        self.result = None

        layout = QVBoxLayout()
        
        label = QLabel("Pilih aplikasi yang ingin Anda picu:")
        label.setAlignment(Qt.AlignCenter)
        layout.addWidget(label)

        button_layout = QHBoxLayout()
        
        btn_chrome = QPushButton("Buka Chrome")
        btn_chrome.clicked.connect(lambda: self.set_result_and_accept('chrome'))
        button_layout.addWidget(btn_chrome)

        btn_galaxy_store = QPushButton("Buka Galaxy Store")
        btn_galaxy_store.clicked.connect(lambda: self.set_result_and_accept('galaxy_store'))
        button_layout.addWidget(btn_galaxy_store)

        layout.addLayout(button_layout)
        self.setLayout(layout)

    def set_result_and_accept(self, choice):
        self.result = choice
        self.accept()


# Kelas Plugin Utama (Perlu penyesuaian untuk progress dialog)
class TriggerAppPlugin(FRPToolPlugin):
    def __init__(self):
        super().__init__()
        self.trigger_app_thread = None
        self.progress_dialog = None
        print("DEBUG: TriggerAppPlugin: __init__ called.")

    def get_name(self):
        return "Picu Aplikasi"

    def create_button(self, parent_widget: QWidget):
        button = super().create_button(parent_widget)
        button.setStyleSheet("background-color: #ffc107; color: black;")
        return button

    def execute(self, log_callback, set_progress_callback, main_app_instance):
        print("DEBUG: TriggerAppPlugin: execute() called.")
        self.log_callback = log_callback
        self.set_progress_callback = set_progress_callback
        self.main_app_instance = main_app_instance

        current_device_info = self.main_app_instance.device_detector.get_device_info()
        print(f"DEBUG: TriggerAppPlugin: Device info - ADB: {current_device_info['is_adb']}, MTP: {current_device_info['is_mtp']}")

        if not current_device_info['is_mtp'] and not current_device_info['is_adb']:
            QMessageBox.warning(None, "Perangkat Tidak Siap", "Ponsel harus terhubung dalam mode MTP atau ADB untuk menggunakan fitur ini.")
            self.log_callback("❌ Error: Ponsel tidak terhubung dalam mode MTP atau ADB.")
            self.set_progress_callback(0)
            return

        if current_device_info['is_mtp'] and not current_device_info['is_adb']:
            reply = QMessageBox.question(
                None, "Konfirmasi Mode",
                "Ponsel terhubung dalam mode MTP. Pastikan Anda telah menekan *#0*# di dialer ponsel untuk mengaktifkan Test Mode.\n\n"
                "Apakah Anda sudah melakukannya?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No
            )
            if reply == QMessageBox.No:
                self.log_callback("Operasi dibatalkan oleh pengguna (instruksi Test Mode belum diikuti).")
                self.set_progress_callback(0)
                return
        
        choice_dialog = TriggerAppChoiceDialog()
        if choice_dialog.exec_() == QDialog.Accepted:
            command_type = choice_dialog.result
            if command_type:
                self.log_callback(f"Pilihan pengguna: Buka {command_type.replace('_', ' ').capitalize()}.")
                
                # BARU: Inisialisasi progress dialog di sini
                self.progress_dialog = QProgressDialog(f"Memicu {command_type.replace('_', ' ').capitalize()}...", "Batalkan", 0, 100, self.main_app_instance)
                self.progress_dialog.setWindowModality(Qt.WindowModal)
                self.progress_dialog.setWindowTitle(f"Proses Membuka {command_type.replace('_', ' ').capitalize()}")
                self.progress_dialog.setMinimumDuration(0)
                self.progress_dialog.setValue(0)
                # Jika ingin tombol batal, hubungkan ke slot untuk menghentikan thread
                # self.progress_dialog.canceled.connect(self.cancel_operation) 
                self.progress_dialog.setCancelButton(None) # Saat ini dibatalkan tidak di-support

                # DIPERBAIKI: Pindahkan koneksi sinyal ke sini sebelum start
                self.trigger_app_thread = TriggerAppThread(command_type, self.main_app_instance.device_detector)
                self.trigger_app_thread.log_signal.connect(self.log_callback)
                self.trigger_app_thread.progress_signal.connect(self.set_progress_callback)
                # Hubungkan progress signal ke dialog juga
                self.trigger_app_thread.progress_signal.connect(self.progress_dialog.setValue)
                self.trigger_app_thread.operation_finished_signal.connect(self._on_operation_finished)
                
                self.trigger_app_thread.start()
                self.progress_dialog.show() # Tampilkan dialog setelah thread dimulai
            else:
                self.log_callback("Pilihan dibatalkan oleh pengguna.")
                self.set_progress_callback(0)
        else:
            self.log_callback("Pilihan dibatalkan oleh pengguna.")
            self.set_progress_callback(0)

    def _on_operation_finished(self, success, message):
        print(f"DEBUG: TriggerAppPlugin: _on_operation_finished called. Success: {success}, Message: {message}")
        # DIPERBAIKI: Cek objek progress_dialog, bukan hanya hasattr
        if self.progress_dialog is not None and self.progress_dialog.isVisible():
            print("DEBUG: TriggerAppPlugin: Closing progress dialog.")
            self.progress_dialog.close()
            self.progress_dialog = None # Hapus referensi
            
        self.log_callback(f"Status operasi: {'✅ Berhasil' if success else '❌ Gagal'}. Pesan: {message}")
        if success:
            QMessageBox.information(self.main_app_instance, "Operasi Berhasil", message)
        else:
            QMessageBox.critical(self.main_app_instance, "Operasi Gagal", message)