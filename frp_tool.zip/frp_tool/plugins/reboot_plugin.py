import os
import subprocess
from PyQt5.QtWidgets import (QWidget, QVBoxLayout, QPushButton, QLabel, 
                             QComboBox, QMessageBox)
from PyQt5.QtCore import QProcess
from interface_plugin import PluginInterface

class RebootPlugin(PluginInterface):
    def get_name(self):
        return "Reboot Device"

    def get_widget(self, parent):
        widget = QWidget(parent)
        layout = QVBoxLayout()

        # Label judul
        title = QLabel("Reboot Perangkat Android")
        title.setStyleSheet("font-weight: bold; font-size: 14px;")
        layout.addWidget(title)

        # Dropdown list perangkat
        self.device_combo = QComboBox()
        self.refresh_devices()  # Memuat daftar perangkat
        layout.addWidget(self.device_combo)

        # Tombol refresh
        btn_refresh = QPushButton("Refresh Perangkat")
        btn_refresh.clicked.connect(self.refresh_devices)
        layout.addWidget(btn_refresh)

        # Tombol reboot
        btn_reboot = QPushButton("REBOOT")
        btn_reboot.setStyleSheet("background-color: #f44336; color: white;")
        btn_reboot.clicked.connect(self.execute_reboot)
        layout.addWidget(btn_reboot)

        # Status
        self.status_label = QLabel("Status: Siap")
        layout.addWidget(self.status_label)

        widget.setLayout(layout)
        return widget

    def refresh_devices(self):
        """Mengambil daftar perangkat Android yang terhubung via ADB"""
        self.device_combo.clear()
        try:
            result = subprocess.run(
                ["adb", "devices"],
                capture_output=True,
                text=True,
                timeout=5
            )
            devices = [
                line.split("\t")[0]
                for line in result.stdout.splitlines()[1:]
                if line.strip() and "offline" not in line
            ]
            
            if not devices:
                self.device_combo.addItem("Tidak ada perangkat terhubung")
                self.status_label.setText("Status: Tidak ada perangkat")
            else:
                self.device_combo.addItems(devices)
                self.status_label.setText(f"Status: {len(devices)} perangkat terdeteksi")
                
        except Exception as e:
            self.device_combo.addItem("Error: ADB tidak ditemukan")
            self.status_label.setText("Status: Gagal memindai perangkat")

    def execute_reboot(self):
        """Menjalankan perintah reboot ke perangkat yang dipilih"""
        selected_device = self.device_combo.currentText()
        
        if not selected_device or "Tidak ada" in selected_device or "Error" in selected_device:
            QMessageBox.warning(None, "Error", "Tidak ada perangkat valid yang dipilih!")
            return

        try:
            self.status_label.setText("Status: Mereboot...")
            
            # Jalankan perintah adb reboot
            process = QProcess()
            process.start("adb", ["-s", selected_device, "reboot"])
            process.waitForFinished()
            
            if process.exitCode() == 0:
                self.status_label.setText("Status: Reboot berhasil dikirim!")
                QMessageBox.information(None, "Sukses", "Perintah reboot berhasil!")
            else:
                error = process.readAllStandardError().data().decode()
                self.status_label.setText("Status: Gagal")
                QMessageBox.critical(None, "Error", f"Gagal reboot:\n{error}")
                
        except Exception as e:
            self.status_label.setText("Status: Error")
            QMessageBox.critical(None, "Error", f"Terjadi kesalahan:\n{str(e)}")