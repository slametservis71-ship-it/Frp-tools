# plugin_interface.py
from PyQt5.QtWidgets import QPushButton, QWidget # Pastikan QWidget diimpor di sini juga

class FRPToolPlugin:
    """
    Kelas dasar (interface) untuk semua plugin FRP Bypass Tool.
    Setiap plugin harus mewarisi kelas ini.
    """
    def get_name(self):
        """
        Mengembalikan nama plugin yang akan ditampilkan di tombol.
        Harus di-override oleh subkelas.
        """
        raise NotImplementedError("Subkelas harus mengimplementasikan metode 'get_name'")

    def create_button(self, parent_widget: QWidget):
        """
        Membuat dan mengembalikan objek QPushButton untuk plugin ini.
        Parent widget diberikan untuk styling atau penempatan jika diperlukan.
        Harus di-override oleh subkelas.
        """
        button = QPushButton(self.get_name(), parent_widget)
        return button

    def execute(self, log_callback, set_progress_callback, main_app_instance):
        """
        Metode utama yang dijalankan ketika tombol plugin diklik.
        log_callback: Fungsi untuk menulis pesan ke konsol log aplikasi utama.
        set_progress_callback: Fungsi untuk mengatur nilai progress bar (0-100).
        main_app_instance: Instance dari aplikasi utama (FRPBypassTool).
                           Digunakan untuk mengakses elemen atau data dari aplikasi utama.
        Harus di-override oleh subkelas.
        """
        raise NotImplementedError("Subkelas harus mengimplementasikan metode 'execute'")

